#!/bin/bash
O=/dev/mmcblk0

PCONF=$(./mmc extcsd read $O | grep PARTITION_CONFIG)
if [[ $? -ne 0 ]]; then #error reading pconf
	echo "${O} is no EMMC, using other mmc-device";
	O=/dev/mmcblk1
	PCONF=$(./mmc extcsd read $O | grep PARTITION_CONFIG)
	if [[ $? -ne 0 ]]; then #error reading pconf
		echo "$O is not emmc too...exiting";exit;
	fi
fi

if [[ ! ${PCONF} =~ 0x48 ]];then
	echo "pconf update needed";
	./mmc bootpart enable 1 1 $O
else
	echo "pconf of ${O} ok"
fi

#set -x
EMMC_PRELOADER=preloader_evb7622_64_foremmc.bin
echo writing emmc-preloader to boot0
RODEV=/sys/block/${O//\/dev\//}boot0/force_ro
echo 0 > $RODEV
dd if=$EMMC_PRELOADER	of=${O}boot0

PRELOADER=preloader_evb7622_64_forsdcard-2k.img
ATF=BPI-R64-atf.img

#u-boot-mtk_r64_emmc_mt7531_gcc8.3.bin
#u-boot-mtk_r64_emmc_rtl8367_gcc8.3.bin
UBOOT=u-boot-mtk_r64_emmc_mt7531_gcc8.3.bin

HEAD0=BPI-R2-HEAD440-0k.img
HEAD1=BPI-R2-HEAD1-512b.img

dd if=$HEAD0 	of=$O bs=512 seek=0 #0
dd if=$HEAD1 	of=$O bs=512 seek=1 #512 = 0x200
dd if=$PRELOADER 	of=$O bs=1k seek=2 #2k = 0x800
dd if=$ATF 	of=$O bs=1k seek=512 #512k = 0x80000
dd if=$UBOOT 	of=$O bs=1k seek=768 #768k = 0xC0000

which mkfs.vfat &>/dev/null
if [[ $? -ne 0 ]];
then
	apt update && apt install dosfstools
fi
sfdisk $O < parttable.dat
mkfs -t vfat ${O}p1
mkfs -t ext4 ${O}p2
